#!/usr/bin/env python3
"""
Gaia Stellar Data Importer

This script queries the Gaia DR3 database for stellar data including
position, velocity, mass, radius, and luminosity, and converts coordinates
to XYZ Cartesian format.
"""

import argparse
import sys
import numpy as np
from astroquery.gaia import Gaia
import pandas as pd


def radec_to_xyz(ra, dec, parallax):
    """
    Convert RA, Dec, and parallax to Cartesian XYZ coordinates.
    
    Parameters:
    -----------
    ra : array-like
        Right Ascension in degrees
    dec : array-like
        Declination in degrees
    parallax : array-like
        Parallax in milliarcseconds
    
    Returns:
    --------
    x, y, z : arrays
        Cartesian coordinates in parsecs
    """
    # Convert parallax (mas) to distance (pc)
    # distance = 1000 / parallax (when parallax is in mas)
    distance = 1000.0 / parallax
    
    # Convert RA and Dec to radians
    ra_rad = np.radians(ra)
    dec_rad = np.radians(dec)
    
    # Convert to Cartesian coordinates
    x = distance * np.cos(dec_rad) * np.cos(ra_rad)
    y = distance * np.cos(dec_rad) * np.sin(ra_rad)
    z = distance * np.sin(dec_rad)
    
    return x, y, z


def query_stellar_data(max_results=1000, output_file='gaia_stellar_data.csv', 
                       min_parallax=1.0):
    """
    Query Gaia DR3 for stellar data with physical parameters.
    
    Parameters:
    -----------
    max_results : int
        Maximum number of results to retrieve (default: 1000)
    output_file : str
        Output CSV filename (default: gaia_stellar_data.csv)
    min_parallax : float
        Minimum parallax in mas to ensure reliable distances (default: 1.0)
    
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing the stellar data with XYZ coordinates
    """
    
    print("Connecting to Gaia archive...")
    print(f"Querying stellar data from Gaia DR3 (up to {max_results} stars)...")
    print(f"Filtering for parallax > {min_parallax} mas for reliable distances...")
    
    # ADQL query to get stellar data from Gaia DR3
    # Join gaia_source with astrophysical_parameters for physical properties
    query = f"""
    SELECT TOP {max_results}
        g.source_id,
        g.ra,
        g.dec,
        g.parallax,
        g.parallax_error,
        g.pmra,
        g.pmdec,
        g.radial_velocity,
        g.phot_g_mean_mag,
        ap.teff_gspphot,
        ap.logg_gspphot,
        ap.mh_gspphot,
        ap.distance_gspphot,
        ap.radius_flame,
        ap.lum_flame,
        ap.mass_flame,
        ap.age_flame
    FROM gaiadr3.gaia_source AS g
    JOIN gaiadr3.astrophysical_parameters AS ap USING (source_id)
    WHERE g.parallax > {min_parallax}
        AND g.parallax_error IS NOT NULL
        AND ap.radius_flame IS NOT NULL
        AND ap.lum_flame IS NOT NULL
        AND ap.mass_flame IS NOT NULL
    ORDER BY g.parallax DESC
    """
    
    try:
        # Execute the query
        job = Gaia.launch_job(query)
        results = job.get_results()
        
        # Convert to pandas DataFrame
        df = results.to_pandas()
        
        print(f"\nSuccessfully retrieved {len(df)} stars with complete parameters!")
        
        # Convert coordinates to XYZ
        print("\nConverting coordinates to Cartesian XYZ...")
        x, y, z = radec_to_xyz(df['ra'].values, df['dec'].values, df['parallax'].values)
        
        # Add XYZ columns to dataframe
        df['x_pc'] = x
        df['y_pc'] = y
        df['z_pc'] = z
        
        # Calculate total velocity magnitude if radial_velocity is available
        df['has_rv'] = ~df['radial_velocity'].isna()
        
        # Display summary statistics
        print("\n" + "="*70)
        print("STELLAR DATA SUMMARY")
        print("="*70)
        print(f"\nTotal stars retrieved: {len(df)}")
        print(f"Stars with radial velocity: {df['has_rv'].sum()}")
        
        print(f"\n--- POSITION (Cartesian Coordinates) ---")
        print(f"X range: {df['x_pc'].min():.2f} to {df['x_pc'].max():.2f} pc")
        print(f"Y range: {df['y_pc'].min():.2f} to {df['y_pc'].max():.2f} pc")
        print(f"Z range: {df['z_pc'].min():.2f} to {df['z_pc'].max():.2f} pc")
        
        print(f"\n--- DISTANCE ---")
        distance_pc = 1000.0 / df['parallax']
        print(f"Closest star: {distance_pc.min():.2f} pc")
        print(f"Farthest star: {distance_pc.max():.2f} pc")
        print(f"Mean distance: {distance_pc.mean():.2f} pc")
        
        print(f"\n--- VELOCITY (Proper Motion) ---")
        print(f"PM RA range: {df['pmra'].min():.2f} to {df['pmra'].max():.2f} mas/yr")
        print(f"PM Dec range: {df['pmdec'].min():.2f} to {df['pmdec'].max():.2f} mas/yr")
        if df['has_rv'].sum() > 0:
            rv_data = df[df['has_rv']]['radial_velocity']
            print(f"Radial velocity range: {rv_data.min():.2f} to {rv_data.max():.2f} km/s")
        
        print(f"\n--- MASS ---")
        print(f"Range: {df['mass_flame'].min():.3f} to {df['mass_flame'].max():.3f} solar masses")
        print(f"Mean: {df['mass_flame'].mean():.3f} solar masses")
        
        print(f"\n--- RADIUS ---")
        print(f"Range: {df['radius_flame'].min():.3f} to {df['radius_flame'].max():.3f} solar radii")
        print(f"Mean: {df['radius_flame'].mean():.3f} solar radii")
        
        print(f"\n--- LUMINOSITY ---")
        print(f"Range: {df['lum_flame'].min():.3e} to {df['lum_flame'].max():.3e} solar luminosities")
        print(f"Mean: {df['lum_flame'].mean():.3e} solar luminosities")
        
        print(f"\n--- TEMPERATURE ---")
        print(f"Range: {df['teff_gspphot'].min():.0f} to {df['teff_gspphot'].max():.0f} K")
        print(f"Mean: {df['teff_gspphot'].mean():.0f} K")
        
        # Save to CSV
        df.to_csv(output_file, index=False)
        print(f"\n{'='*70}")
        print(f"Data exported to: {output_file}")
        print(f"{'='*70}\n")
        
        return df
        
    except Exception as e:
        print(f"Error querying Gaia database: {e}", file=sys.stderr)
        sys.exit(1)


def query_nearby_stars(distance_pc=100, max_results=10000, output_file='gaia_nearby_stars.csv'):
    """
    Query Gaia DR3 for nearby stars within a specified distance.
    
    Parameters:
    -----------
    distance_pc : float
        Maximum distance in parsecs (default: 100 pc)
    max_results : int
        Maximum number of results to retrieve (default: 10000)
    output_file : str
        Output CSV filename
    
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing nearby stellar data with XYZ coordinates
    """
    
    # Convert distance to minimum parallax
    min_parallax = 1000.0 / distance_pc
    
    print(f"\nSearching for stars within {distance_pc} pc...")
    print(f"(Parallax > {min_parallax:.3f} mas)")
    
    # Query with distance constraint
    query = f"""
    SELECT TOP {max_results}
        g.source_id,
        g.ra,
        g.dec,
        g.parallax,
        g.parallax_error,
        g.pmra,
        g.pmdec,
        g.radial_velocity,
        g.phot_g_mean_mag,
        ap.teff_gspphot,
        ap.logg_gspphot,
        ap.mh_gspphot,
        ap.distance_gspphot,
        ap.radius_flame,
        ap.lum_flame,
        ap.mass_flame,
        ap.age_flame
    FROM gaiadr3.gaia_source AS g
    LEFT JOIN gaiadr3.astrophysical_parameters AS ap USING (source_id)
    WHERE g.parallax > {min_parallax}
        AND g.parallax_error IS NOT NULL
    ORDER BY g.parallax DESC
    """
    
    try:
        job = Gaia.launch_job(query)
        results = job.get_results()
        df = results.to_pandas()
        
        print(f"\nFound {len(df)} stars within {distance_pc} pc!")
        
        # Convert coordinates to XYZ
        x, y, z = radec_to_xyz(df['ra'].values, df['dec'].values, df['parallax'].values)
        df['x_pc'] = x
        df['y_pc'] = y
        df['z_pc'] = z
        
        # Calculate actual distance
        df['distance_pc'] = 1000.0 / df['parallax']
        
        print(f"\nClosest star: {df['distance_pc'].min():.2f} pc")
        print(f"Stars with physical parameters: {(~df['mass_flame'].isna()).sum()}")
        
        # Save to CSV
        df.to_csv(output_file, index=False)
        print(f"\nData exported to: {output_file}\n")
        
        return df
        
    except Exception as e:
        print(f"Error querying Gaia database: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """Main function to handle command-line arguments."""
    
    parser = argparse.ArgumentParser(
        description='Query stellar data from Gaia DR3 with XYZ coordinates'
    )
    
    parser.add_argument(
        '-n', '--max-results',
        type=int,
        default=1000,
        help='Maximum number of results to retrieve (default: 1000)'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        default='gaia_stellar_data.csv',
        help='Output CSV filename (default: gaia_stellar_data.csv)'
    )
    
    parser.add_argument(
        '-p', '--min-parallax',
        type=float,
        default=1.0,
        help='Minimum parallax in mas for reliable distances (default: 1.0)'
    )
    
    parser.add_argument(
        '--nearby',
        type=float,
        help='Query stars within specified distance in parsecs (e.g., --nearby 100)'
    )
    
    args = parser.parse_args()
    
    print("\n" + "="*70)
    print("GAIA STELLAR DATA IMPORTER")
    print("="*70 + "\n")
    
    if args.nearby:
        # Query nearby stars
        query_nearby_stars(args.nearby, args.max_results, args.output)
    else:
        # Query general stellar data
        query_stellar_data(args.max_results, args.output, args.min_parallax)


if __name__ == '__main__':
    main()
