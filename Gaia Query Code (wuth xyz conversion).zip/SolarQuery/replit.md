# Gaia Stellar Data Importer

## Overview

This project is a Python-based data extraction tool that queries the Gaia DR3 (Data Release 3) astronomical database to retrieve and export stellar data with physical parameters. The application fetches position (with XYZ Cartesian coordinates), velocity, mass, radius, and luminosity data for stars and outputs the results in CSV format with summary statistics.

**Status**: Fully implemented and tested (October 23, 2025)

## Recent Changes

### October 23, 2025
- ✅ Implemented complete Gaia DR3 stellar data importer
- ✅ Added coordinate conversion from RA/Dec/parallax to XYZ Cartesian coordinates
- ✅ Query stars with position, velocity, mass, radius, and luminosity
- ✅ Implemented CSV export with comprehensive summary statistics
- ✅ Successfully tested with Gaia archive (retrieved 100 stars with complete physical parameters)
- ✅ Created workflow for automated script execution
- ✅ Added nearby star query functionality

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Type
Command-line interface (CLI) Python script designed for scientific data extraction and analysis.

### Core Components

**Data Acquisition Layer**
- Uses `astroquery.gaia` library to connect to the European Space Agency's Gaia archive
- Implements ADQL (Astronomical Data Query Language) queries to fetch stellar data by joining:
  - `gaia_source` table (position, parallax, proper motion, radial velocity)
  - `astrophysical_parameters` table (mass, radius, luminosity, temperature, age)
- Queries retrieve specific fields including:
  - Position: RA, Dec, parallax (with conversion to XYZ Cartesian coordinates)
  - Velocity: proper motion (RA/Dec), radial velocity
  - Physical parameters: mass, radius, luminosity (in solar units)
  - Atmospheric parameters: temperature, surface gravity, metallicity
  - Derived parameters: age, distance

**Data Processing Layer**
- Coordinate conversion from spherical (RA/Dec/parallax) to Cartesian (XYZ) coordinates
- Distance calculation: distance(pc) = 1000 / parallax(mas)
- XYZ coordinates centered on the Sun using standard conversion formulas
- Utilizes pandas DataFrames for in-memory data manipulation
- NumPy for numerical operations and coordinate transformations
- Configurable result limits and distance filters

**Export Layer**
- CSV file export functionality for downstream analysis
- Comprehensive summary statistics including:
  - Position ranges (XYZ Cartesian coordinates in parsecs)
  - Distance statistics (closest, farthest, mean)
  - Velocity ranges (proper motion and radial velocity)
  - Physical parameter distributions (mass, radius, luminosity)
  - Temperature ranges and stellar counts

### Design Patterns

**Configuration via CLI Arguments**
- Uses argparse for parameter configuration
- Allows customization of query limits and output destinations
- Promotes reusability across different use cases

**Functional Design**
- Modular function structure for clear separation of concerns:
  - `query_stellar_data()` - General stellar data query with physical parameters
  - `query_nearby_stars()` - Query stars within specified distance
  - `radec_to_xyz()` - Coordinate conversion utility
- Single responsibility: data query, coordinate conversion, and export

## External Dependencies

### Scientific Libraries
- **astroquery** - Primary interface to astronomical databases (Gaia archive)
- **pandas** - Data manipulation and CSV export
- **numpy** - Numerical computing and statistical operations

### Data Source
- **Gaia DR3 Archive** - European Space Agency's Gaia mission database (~1.8 billion stars)
- Uses ADQL query protocol for remote data access
- Targets multiple tables:
  - `gaia_source` - Core astrometric and photometric data
  - `astrophysical_parameters` - Derived physical parameters (mass, radius, luminosity)

### Python Standard Library
- **argparse** - Command-line argument parsing
- **sys** - System-specific parameters and functions
- **pathlib** - Object-oriented filesystem path handling