# Gaia Solar System Data Importer

## Overview

This project is a Python-based data extraction tool that queries the Gaia DR3 (Data Release 3) astronomical database to retrieve and export solar system object observations. The application fetches astrometric and photometric data for celestial objects and outputs the results in CSV format with summary statistics.

**Status**: Fully implemented and tested (October 2, 2025)

## Recent Changes

### October 2, 2025
- ✅ Implemented complete Gaia DR3 solar system data importer
- ✅ Added bulk query functionality for retrieving multiple solar system objects
- ✅ Added specific object search with sanitized input (ADQL injection protection)
- ✅ Implemented CSV export with comprehensive summary statistics
- ✅ Successfully tested with Gaia archive (retrieved 50 objects in bulk, 186 Ceres observations in search)
- ✅ Created workflow for automated script execution

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Type
Command-line interface (CLI) Python script designed for scientific data extraction and analysis.

### Core Components

**Data Acquisition Layer**
- Uses `astroquery.gaia` library to connect to the European Space Agency's Gaia archive
- Implements ADQL (Astronomical Data Query Language) queries to fetch solar system observations from the `sso_observation` table
- Queries retrieve specific fields including:
  - Object identifiers (source_id, denomination, number_mp)
  - Temporal data (epoch)
  - Positional data (RA/Dec coordinates with error measurements)
  - Photometric data (g_mag magnitude)
  - Scan geometry (position_angle_scan)

**Data Processing Layer**
- Utilizes pandas DataFrames for in-memory data manipulation
- NumPy for numerical operations and statistical calculations
- Configurable result limits to manage data volume

**Export Layer**
- CSV file export functionality for downstream analysis
- Comprehensive summary statistics including magnitude, position accuracy, epoch range, and object counts

### Design Patterns

**Configuration via CLI Arguments**
- Uses argparse for parameter configuration
- Allows customization of query limits and output destinations
- Promotes reusability across different use cases

**Functional Design**
- Modular function structure (query_gaia_solar_system) for clear separation of concerns
- Single responsibility: data query and export

## External Dependencies

### Scientific Libraries
- **astroquery** - Primary interface to astronomical databases (Gaia archive)
- **pandas** - Data manipulation and CSV export
- **numpy** - Numerical computing and statistical operations

### Data Source
- **Gaia DR3 Archive** - European Space Agency's Gaia mission database
- Uses ADQL query protocol for remote data access
- Specifically targets the `sso_observation` table containing solar system object observations

### Python Standard Library
- **argparse** - Command-line argument parsing
- **sys** - System-specific parameters and functions
- **pathlib** - Object-oriented filesystem path handling