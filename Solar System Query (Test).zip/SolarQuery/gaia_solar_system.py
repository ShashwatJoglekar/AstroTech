#!/usr/bin/env python3
"""
Gaia Solar System Data Importer

This script queries the Gaia DR3 database for solar system objects
and exports the data to CSV format with summary statistics.
"""

import argparse
import sys
from pathlib import Path
from astroquery.gaia import Gaia
import pandas as pd
import numpy as np


def query_gaia_solar_system(max_results=100, output_file='gaia_solar_system_data.csv'):
    """
    Query Gaia DR3 for solar system objects.
    
    Parameters:
    -----------
    max_results : int
        Maximum number of results to retrieve (default: 100)
    output_file : str
        Output CSV filename (default: gaia_solar_system_data.csv)
    
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing the solar system object data
    """
    
    print("Connecting to Gaia archive...")
    print("Querying solar system objects from Gaia DR3...")
    
    # ADQL query to get solar system objects from Gaia DR3
    # The sso_observation table contains individual observations with astrometry and photometry
    query = f"""
    SELECT TOP {max_results}
        source_id,
        denomination,
        number_mp,
        epoch,
        ra,
        dec,
        ra_error_random,
        dec_error_random,
        g_mag,
        position_angle_scan
    FROM gaiadr3.sso_observation
    ORDER BY epoch DESC
    """
    
    try:
        # Execute the query
        job = Gaia.launch_job(query)
        results = job.get_results()
        
        # Convert to pandas DataFrame
        df = results.to_pandas()
        
        print(f"\nSuccessfully retrieved {len(df)} solar system objects!")
        
        # Display summary statistics
        print("\n" + "="*60)
        print("DATA SUMMARY")
        print("="*60)
        print(f"\nTotal objects retrieved: {len(df)}")
        
        if len(df) > 0:
            print(f"\nObject types (denominations): {df['denomination'].nunique()} unique")
            
            print(f"\nSample of objects:")
            unique_objects = df['denomination'].unique()[:5]
            for obj in unique_objects:
                print(f"  - {obj}")
            
            print(f"\nMagnitude statistics (G-band):")
            print(f"  Mean: {df['g_mag'].mean():.2f}")
            print(f"  Min:  {df['g_mag'].min():.2f}")
            print(f"  Max:  {df['g_mag'].max():.2f}")
            
            print(f"\nPosition accuracy (RA random error):")
            print(f"  Mean: {df['ra_error_random'].mean():.4f} mas")
            print(f"  Min:  {df['ra_error_random'].min():.4f} mas")
            print(f"  Max:  {df['ra_error_random'].max():.4f} mas")
            
            print(f"\nEpoch range:")
            print(f"  Earliest: {df['epoch'].min():.2f}")
            print(f"  Latest:   {df['epoch'].max():.2f}")
        
        # Save to CSV
        df.to_csv(output_file, index=False)
        print(f"\n{'='*60}")
        print(f"Data exported to: {output_file}")
        print(f"{'='*60}\n")
        
        return df
        
    except Exception as e:
        print(f"Error querying Gaia database: {e}", file=sys.stderr)
        sys.exit(1)


def query_specific_object(object_name, output_file=None):
    """
    Query Gaia DR3 for a specific solar system object by name.
    
    Parameters:
    -----------
    object_name : str
        Name or designation of the solar system object
    output_file : str
        Output CSV filename (optional)
    
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing the object data
    """
    
    print(f"Searching for '{object_name}' in Gaia DR3...")
    
    # Escape single quotes to prevent ADQL injection
    sanitized_name = object_name.replace("'", "''")
    
    query = f"""
    SELECT 
        source_id,
        denomination,
        number_mp,
        epoch,
        ra,
        dec,
        ra_error_random,
        dec_error_random,
        g_mag,
        position_angle_scan
    FROM gaiadr3.sso_observation
    WHERE LOWER(denomination) LIKE LOWER('%{sanitized_name}%')
    ORDER BY epoch DESC
    """
    
    try:
        job = Gaia.launch_job(query)
        results = job.get_results()
        df = results.to_pandas()
        
        if len(df) == 0:
            print(f"No objects found matching '{object_name}'")
            return None
        
        print(f"\nFound {len(df)} observation(s) for '{object_name}'")
        print("\n" + "="*60)
        print(df.to_string(index=False))
        print("="*60 + "\n")
        
        if output_file:
            df.to_csv(output_file, index=False)
            print(f"Data exported to: {output_file}\n")
        
        return df
        
    except Exception as e:
        print(f"Error querying Gaia database: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """Main function to handle command-line arguments."""
    
    parser = argparse.ArgumentParser(
        description='Query and import solar system data from the Gaia DR3 database'
    )
    
    parser.add_argument(
        '-n', '--max-results',
        type=int,
        default=100,
        help='Maximum number of results to retrieve (default: 100)'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        default='gaia_solar_system_data.csv',
        help='Output CSV filename (default: gaia_solar_system_data.csv)'
    )
    
    parser.add_argument(
        '-s', '--search',
        type=str,
        help='Search for a specific solar system object by name'
    )
    
    args = parser.parse_args()
    
    print("\n" + "="*60)
    print("GAIA SOLAR SYSTEM DATA IMPORTER")
    print("="*60 + "\n")
    
    if args.search:
        # Search for specific object
        query_specific_object(args.search, args.output)
    else:
        # Query general solar system data
        query_gaia_solar_system(args.max_results, args.output)


if __name__ == '__main__':
    main()
